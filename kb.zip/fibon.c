//Display terms of fibonacci sequence using recursion
#include<stdio.h>
// declare  function prototype
void displayTerms(int n,int x,int y);

int main(){
int first=1,second=1,max_num;
printf("Enter max number:\n");
scanf("%d",&max_num);

if(max_num>0){
printf("Terms of the  fibonacci sequence up to %d are: \n",max_num);
printf("%d",first);
displayTerms(first,  second,  max_num);
}
else{
    printf("there is no term");
}
}
void displayTerms(int first,int second, int max_num){
if(second<=max_num){
printf(",%d",second);
int next=first+second;
first=second;
displayTerms(second,next,max_num);
}
}
